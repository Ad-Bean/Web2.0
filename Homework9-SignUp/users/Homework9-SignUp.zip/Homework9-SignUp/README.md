# Homework 9 - Sign Up

## 注意事项

请在根目录下在终端运行

```bash
node server.js
```

后在浏览器打开[localhost:8000](http://localhost:8000/)

```
** Server running at http://localhost:8000/ **
Press Ctrl+C to stop the server
```

若打开后为空白页面，请检查是否在根目录下启动server.js

